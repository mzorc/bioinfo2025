# This code is a part of Maternal Genealogy Lineage Analyser - MaGelLAn-v2.1demo.
# MaGelLAn is an open source software and it is free for non-commercial use, as long as it is properly referenced.
# Authors are Ino Curik, Dalibor Hrsak and Strahil Ristov



import platform
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import sys
from os import path
from PyQt6.QtWidgets import QMessageBox, QFileDialog
from PIL import Image, ImageDraw, ImageFont


def build_tree(data,founder,ancestor_line):

    graph_tree = data.loc[data['ID']==founder].values.tolist()
    ancestors = [founder]
    ancestor_offspring_pairs = data.loc[data[ancestor_line].isin(ancestors)]

    generation = 0
    generation_list = [0]
    while len(ancestor_offspring_pairs):
        generation += 1
        for row in ancestor_offspring_pairs.values.tolist():
            graph_tree.append(row)
        generation_list.extend(len(ancestor_offspring_pairs)*[generation])
        ancestors = list(ancestor_offspring_pairs['ID'])
        ancestor_offspring_pairs = data.loc[data[ancestor_line].isin(ancestors)]

    affected = np.ones(np.shape(np.array(graph_tree)[:,0]),dtype=int)
    graph_tree = np.hstack((graph_tree,np.expand_dims(generation_list,axis=1),np.expand_dims(affected,axis=1)))

    return np.array(graph_tree)

def fix_data(data,lineage,ID):
    
    data = data.astype({'generation':int})

    first_gen = min(data["generation"])
    #set first included generation to be founders with unknown father and mother
    if first_gen > 0.0:
        data["generation"] = data["generation"] - first_gen
        data['mother'] = data['mother'].where((data["generation"] != 0),other="0")
        data['father'] = data['father'].where((data["generation"] != 0),other="0")

    #kinship2 requires all members to be defined and at least 2 founders

    founder_fathers = pd.DataFrame(data.loc[~data['father'].isin(data['ID'])]['father'])
    founder_mothers = pd.DataFrame(data.loc[~data['mother'].isin(data['ID'])]['mother'])

    founder_fathers.rename(columns={'father':'ID'},inplace=True)
    founder_mothers.rename(columns={'mother':'ID'},inplace=True)

    # remove duplicate items
    founder_fathers.drop_duplicates(subset=['ID'],inplace=True)
    founder_mothers.drop_duplicates(subset=['ID'],inplace=True)
    
    founder_fathers.insert(1,'father','0')
    founder_fathers.insert(2,'mother','0')
    founder_fathers.insert(3,'gender','1')
    founder_fathers.insert(4,'oldID','0')
    founder_mothers.insert(1, 'father', '0')
    founder_mothers.insert(2, 'mother', '0')
    founder_mothers.insert(3, 'gender', '2')
    founder_mothers.insert(4,'oldID','0')
    if lineage == 'paternal':
        founder_fathers.insert(5,'affected','1')
        founder_mothers.insert(5,'affected','0')
    elif lineage == 'maternal':
        founder_fathers.insert(5,'affected','0')
        founder_mothers.insert(5,'affected','1')


    founder_fathers.drop(founder_fathers.loc[founder_fathers['ID'] == '0'].index, inplace=True)
    founder_mothers.drop(founder_mothers.loc[founder_mothers['ID'] == '0'].index, inplace=True)

    founder_generations = []
    for ID in founder_mothers.ID: # bugfix, it was fathers before
        founder_generations.append(min(data.loc[data['mother'] == ID].generation)-1)
    founder_mothers.insert(6,'generation',founder_generations)

    founder_generations = []
    for ID in founder_fathers.ID:
        founder_generations.append(min(data.loc[data['father'] == ID].generation)-1)
    founder_fathers.insert(6,'generation',founder_generations)

    data = pd.concat([data, founder_fathers], ignore_index=True)
    data = pd.concat([data, founder_mothers], ignore_index=True)

    if "haplotype" in data.columns.values:
        data["haplotype"] = data["haplotype"].fillna("")


    dummyID = "unknown"

    filter1 = (data["father"] != "0") & (data["mother"] == "0")
    filter2 = (data["father"] == "0") & (data["mother"] != "0")
    # insert a dummy missing parent
    if lineage == 'paternal':
        data['mother'] = data['mother'].where(~filter1,other=dummyID)
        data['mother'] = data['mother'].where(~filter2,other='0')

    elif lineage == 'maternal':
        data['father'] = data['father'].where(~filter2, other=dummyID)
        data['father'] = data['father'].where(~filter1, other='0')

    return data

# return indices of boxes from boxList satisfying a list of values for a list of keys
def get_box_idx(box_list, key_names, key_values):

    index = []

    for i in range(len(box_list)):
        matches = True
        for key_name, key_value in zip(key_names,key_values):
            if box_list[i][key_name] != key_value:
                matches = False
        if matches:
            index.append(i)

    return index

def quadratic_bezier(t, p0, p1, p2):
    return (
        (1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t ** 2 * p2[0],
        (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t ** 2 * p2[1]
    )


def visualize_line(data,mode,image_filename,image_size,lineage):

    data = data.astype({'generation':int})

    if "haplotype" in data.columns.values:
        haplotyped_individuals = data.loc[data['haplotype'] != '']
        haplotypeMap = dict(zip(haplotyped_individuals.ID, haplotyped_individuals.haplotype))
        haplotypedList = list(haplotyped_individuals['ID'])
        if "sequenced" in haplotyped_individuals.columns.values:
            sequencedList = list(haplotyped_individuals[haplotyped_individuals['sequenced'] == '1']['ID'])

            if "verified" in haplotyped_individuals.columns.values:
                verifiedList = list(haplotyped_individuals.loc[data['verified'] == '1']['ID'])
                unverifiedList = list(haplotyped_individuals.loc[haplotyped_individuals['verified'] == '0']['ID'])
            else:
                verifiedList = list(haplotyped_individuals['ID'])
                unverifiedList = []

        else:
            sequencedList = list(haplotyped_individuals['ID'])
            verifiedList = list(haplotyped_individuals['ID'])
            unverifiedList = []

    else:
        haplotypeMap = dict()
        haplotypedList = []
        sequencedList = []
        verifiedList = []
        unverifiedList = []

    # find number of generations and how many individuals per generation
    generations, counts = np.unique(data.generation,return_counts=True)
    n_generations = len(generations)

    # width and height of the square or circle of every individual
    if image_size == "large":
        ind_size = 100
    elif image_size == "medium":
        ind_size = 50
    elif image_size == "small":
        ind_size = 20

    # calculate tentative image size
    width = max(counts)*ind_size + (max(counts)+2) * 2 * ind_size
    height = (n_generations + 1)*ind_size + (n_generations + 2) * 3 * ind_size

    affectedList = []  # list of individuals pertaining to the same lineage 
    # the basic structure for the contruction of the image is a box
    boxList = []       # list of boxes containing affected individuals and the partners they create progeny with

    # loop over generations and create a box for each affected individual with information on it, its partners and offspring
    for gen in generations:

        thisGenData = data.loc[data["generation"] == gen]
        thisGenData = thisGenData.loc[thisGenData["affected"] == "1"] # we create boxes only for affected individuals

        # loop over affected individuals in this data
        for ID in thisGenData["ID"]:

            affectedList.append(ID)

            nextGenData = data.loc[data["generation"] == gen + 1] # next generation

            # filter all rows in next generation where ID is the ancestor
            if lineage == "maternal":
                nextGenData = nextGenData.loc[nextGenData["mother"] == ID]
            elif lineage == "paternal":
                nextGenData = nextGenData.loc[nextGenData["father"] == ID]
            
            # filter all respective partners of ID
            if lineage == "maternal":
                partnerList = list(set(nextGenData["father"]))
            elif lineage == "paternal":
                partnerList = list(set(nextGenData["mother"]))

            # list of ID's offspring
            offspringList = list(set(nextGenData["ID"]))
            # midpoint is the index of the position where ID is placed in the box
            # it should be at the middle, with partners evenly distributed left and right
            midpoint = len(partnerList)//2 + 1

            # create the new box
            newBox = {"affected_member": ID, 
                      "mother": list(thisGenData.loc[thisGenData["ID"] == ID]["mother"])[0],
                      "father": list(thisGenData.loc[thisGenData["ID"] == ID]["father"])[0],
                      "sex": list(thisGenData.loc[thisGenData["ID"] == ID]["gender"])[0],
                      "generation": gen,
                      "n": len(partnerList)+1, 
                      "members": partnerList,
                      "midpoint": midpoint,
                      "offspring": offspringList}

            # calculate the width of the box based on the number of partners and ID
            newBox["length"] = (2 * len(newBox["members"]) + 1) * ind_size
            # calculate the position of individual centers in the box with respect to its left boundary
            newBox["centers"] = [(i * 2 * ind_size) + ind_size//2 for i in range(len(partnerList)+1)]
            # endpoints of horizontal lines connecting ID with it's partners
            h_linepoints = []
            if len(newBox["centers"]) > 1:
                # horizontal lines connect edges of individuals
                for i in range(len(newBox["centers"])-1):
                    h_linepoints.append([newBox["centers"][i]+(ind_size//2),newBox["centers"][i+1]-(ind_size//2)])
            newBox["h_linepoints"] = h_linepoints

            # box edges on the vertical axis, defined entirely by the ID's generation
            newBox["y_limits"] = [(newBox["generation"]*5*ind_size)+ind_size,(newBox["generation"]*5*ind_size)+2*ind_size]

            # if the boxes for this generation fall outside of the image, increase the image
            if height < newBox["y_limits"][1] + 2 * ind_size:
                height = newBox["y_limits"][1] + 2 * ind_size

            # add the box to the list
            boxList.append(newBox)

    generationBoxLimits = []

    # determine start and end positions for boxes in every generation
    # if their sum is larger than the width of the image, increase the width and start over

    i = 0
    while i < len(generations):
        #filter only boxes in i^th generation
        thisGenBoxes = [box for box in boxList if box["generation"] == generations[i]]
        # total width of all generation's boxes
        length_all = 0
        nBoxes = len(thisGenBoxes) # number of boxes

        # sum the widths of all boxes
        for box in thisGenBoxes:
            length_all += box["length"]

        # add blank space between boxes
        length_all += 2 * ind_size * (nBoxes - 1)

        # if the image is too narrow, widen it, erase the list and start the loop over i again
        if width < length_all + 2 * ind_size:
            width = length_all + 2 * ind_size
            generationBoxLimits = []
            i = 0
        # set boxes distributed evenly, centered around the middle for each row/generation 
        else:
            x_0 = width // 2 - length_all // 2 
            x_1 = width // 2 + length_all // 2 

            # x_left: left border for leftmost box, x_right: right border for rightmost box
            # what boxes have been added to the row already and how much of allocated space has already been occupied (start with x_0)
            generationBoxLimits.append({"generation": generations[i], "x_left": x_0, "x_right": x_1, "added": [], "x_occupied": x_0, "box_order": []})

            i += 1

    # what boxes already have their space allocated
    allocatedSpaceList = []

    # initiate with the zeroth generation
    generation_0 = boxList[0]["generation"] # it is the generation of the first box in the list
    firstGenBoxes = [box for box in boxList if box["generation"] == generation_0]

    # allocate space for each first generation box and move x_occupied for its width + blank space
    for firstGenBox in firstGenBoxes:
        generationBoxLimits[0]["box_order"].append(firstGenBox["affected_member"])
        firstGenBoxIdx = get_box_idx(boxList,["affected_member"],[firstGenBox["affected_member"]])[0]
        length = boxList[firstGenBoxIdx]["length"]
        x_occupied = generationBoxLimits[0]["x_occupied"]
        boxList[firstGenBoxIdx]["x_limits"] = [x_occupied, x_occupied+length]
        generationBoxLimits[0]["x_occupied"] = x_occupied + length + 2 * ind_size
        allocatedSpaceList.append(boxList[firstGenBoxIdx]["affected_member"])


    # list of lists of individuals with same parents
    allSiblingList = []

    # loop over subsequent generations
    for gen_idx in range(1,len(generations)):

        # get indices of this generation members in boxList
        gen_member_idxs = get_box_idx(boxList,["generation"],[generations[gen_idx]])
        # find boxes from previous generation
        prev_gen_box_order = generationBoxLimits[gen_idx-1]["box_order"]

        # loop over previous generation, find its offspring in this generation and add the box on the list
        # keeping the correct previous generation's box order prevents line crossing on the image
        for prev_gen_box in prev_gen_box_order:
            prev_gen_box_idx = get_box_idx(boxList,["affected_member","generation"],[prev_gen_box,generations[gen_idx-1]])[0]
            # we also want the correct partner order to prevent line crossing for individual with same affected parent but different non affected parent
            prev_gen_partners = boxList[prev_gen_box_idx]["members"]

            # loop over partners for each previous generation box
            for prev_gen_partner in prev_gen_partners:

                # find offspring indices for the affected member-partner combination
                if lineage == "maternal":
                    this_gen_offspring_idxs = get_box_idx(boxList,["generation","mother","father"],[generations[gen_idx],prev_gen_box,prev_gen_partner])
                elif lineage == "paternal":
                    this_gen_offspring_idxs = get_box_idx(boxList,["generation","father","mother"],[generations[gen_idx],prev_gen_box,prev_gen_partner])

                # find siblings sharing same mother and father. they will be connnected with a single horizontal line on the image
                siblingList = []
                if len(this_gen_offspring_idxs) > 1:
                    for this_gen_offspring_idx in this_gen_offspring_idxs:
                        siblingList.append(boxList[this_gen_offspring_idx]["affected_member"])
                    allSiblingList.append(siblingList)

                # allocate space on the image for the offspring of that particular mother and father
                for this_gen_offspring_idx in this_gen_offspring_idxs:
                    generationBoxLimits[gen_idx]["box_order"].append(boxList[this_gen_offspring_idx]["affected_member"])
                    length = boxList[this_gen_offspring_idx]["length"]
                    x_occupied = generationBoxLimits[gen_idx]["x_occupied"]
                    boxList[this_gen_offspring_idx]["x_limits"] = [x_occupied, x_occupied+length] # give this box first left free space

                    # give information on it's siblings 
                    if len(this_gen_offspring_idxs) > 1:
                        boxList[this_gen_offspring_idx]["siblings"] = [sibling for sibling in siblingList if sibling != boxList[this_gen_offspring_idx]["affected_member"]]
                    else:
                        boxList[this_gen_offspring_idx]["siblings"] = []
                    
                    generationBoxLimits[gen_idx]["x_occupied"] = x_occupied + length + 2* ind_size # reserve space in limits, add 2 basic sizes space
                    allocatedSpaceList.append(boxList[this_gen_offspring_idx]["affected_member"])

        # when truncating lineage by YOB, some sublineages appear in a generation > 0
        # account for them here, first check if they are in allocatedSpaceList, then add if not
        for gen_member_idx in gen_member_idxs:
            if boxList[gen_member_idx]["affected_member"] not in allocatedSpaceList:
                generationBoxLimits[gen_idx]["box_order"].append(boxList[gen_member_idx]["affected_member"])
                length = boxList[gen_member_idx]["length"]
                x_occupied = generationBoxLimits[gen_idx]["x_occupied"]
                boxList[gen_member_idx]["x_limits"] = [x_occupied, x_occupied+length]          # give this box first left free space
                generationBoxLimits[gen_idx]["x_occupied"] = x_occupied + length + 2* ind_size # reserve space in limits, add 2 basic sizes space
                allocatedSpaceList.append(boxList[gen_member_idx]["affected_member"])


    femaleList = []  # list of all females
    maleList = []    # list of all males
    hLineList = []   # horizontal lines connecting the mother with her partners
    dvLineList = []  # downward vertical line connecting with the offspring
    uvLineList = []  # upward vertical line connecting with the ancestors
    uvLineList1 = [] # upward vertical line connecting with the ancestors and siblings

    # loop over boxes, assign their individuals coordinates on the image
    # also define lines that connect the individuals with their siblings, ancestors and offspring
    for box in boxList:
        xlim = box["x_limits"]

        x_centers = box["centers"]
        y = (box["y_limits"][1]+box["y_limits"][0]) // 2

        h_line_limits = box["h_linepoints"]

        # loop over individuals in the box
        it = 1
        while it <= box["n"]:

            # move x coordinate for the individual by the left box edge
            x = x_centers[it-1] + xlim[0] 

            # first assign partners left of the affected member
            if it < box["midpoint"]:
                ID = box["members"][it-1]
                if ID in affectedList:
                    if lineage == "maternal":
                        maleList.append({"id": ID, "center": (x,y), "radius": ind_size//2, "color": "blue", "affected": "1"})
                    elif lineage == "paternal":
                        femaleList.append({"id": ID, "center": (x,y), "radius": ind_size//2, "color": "blue", "affected": "1"})
                else:
                    if lineage == "maternal":
                        maleList.append({"id": ID, "center": (x,y), "radius": ind_size//2, "color": "blue", "affected": "0"})
                    elif lineage == "paternal":
                        femaleList.append({"id": ID, "center": (x,y), "radius": ind_size//2, "color": "blue", "affected": "0"})

            # then put the affected member in the middle
            elif it == box["midpoint"]:
                ID = box["affected_member"]
                if box["sex"] == "2":
                    femaleList.append({"id": ID, "center": (x,y), "radius": ind_size//2, "color": "blue", "affected": "1"})
                
                elif box["sex"] == "1":
                    maleList.append({"id": ID, "center": (x,y), "radius": ind_size//2, "color": "blue", "affected": "1"})

                # if the member has ancestors, put an upward vertical line from the upper edge to 1.5 the size of the individual
                if (box["father"] != "0") or (box["mother"] != "0"):
                    uv_limits = []
                    # if the individual, put the upward vertical line only 1.25 size and add them to a separate list
                    if len(box["siblings"]):
                        uv_limits.append(y - (5*ind_size//4))
                        uv_limits.append(y - ind_size//2)
                        uvLineList1.append({"id": ID,"parents": [box["father"],box["mother"]],"siblings": box["siblings"], "x_pos": x, "y_pos": uv_limits, "generation": box["generation"]})
                    else:
                        uv_limits.append(y - (3*ind_size//2))
                        uv_limits.append(y - ind_size//2)
                        uvLineList.append({"id": ID,"parents": [box["father"],box["mother"]], "x_pos": x, "y_pos": uv_limits, "generation": box["generation"]})
                
            # then add the remaining partners
            elif it > box["midpoint"]:
                ID = box["members"][it-2]
                if ID in affectedList:
                    if lineage == "maternal":
                        maleList.append({"id": ID, "center": (x,y), "radius": ind_size//2, "color": "blue", "affected": "1"})
                    elif lineage == "paternal":
                        femaleList.append({"id": ID, "center": (x,y), "radius": ind_size//2, "color": "blue", "affected": "1"})
                else:
                    if lineage == "maternal":
                        maleList.append({"id": ID, "center": (x,y), "radius": ind_size//2, "color": "blue", "affected": "0"})
                    elif lineage == "paternal":
                        femaleList.append({"id": ID, "center": (x,y), "radius": ind_size//2, "color": "blue", "affected": "0"})

            # if the affected member has offspring, put horizontal line between the individuals in the box (edge to edge)
            # also put downward vertical lines from the middle of horizonal lines to 1.5 basic size below
            if len(h_line_limits):
                h_limits = []
                dv_limits = []
                if it < box["midpoint"]:
                    h_limits.append(h_line_limits[it-1][0] + xlim[0])
                    h_limits.append(h_line_limits[it-1][1] + xlim[0])
                    hLineList.append({"partners": [box["affected_member"],ID], "endpoints": h_limits, "y_pos": y, "generation": box["generation"]})
                    x_pos = (h_limits[0]+h_limits[1]) // 2
                    dv_limits.append(y)
                    dv_limits.append(y + (3*ind_size//2))
                    dvLineList.append({"partners": [box["affected_member"],ID], "x_pos": x_pos, "y_pos": dv_limits, "generation": box["generation"]})
                elif it > box["midpoint"]:
                    h_limits.append(h_line_limits[it-2][0] + xlim[0])
                    h_limits.append(h_line_limits[it-2][1] + xlim[0])
                    hLineList.append({"partners": [box["affected_member"],ID], "endpoints": h_limits, "y_pos": y, "generation": box["generation"]})
                    x_pos = (h_limits[0]+h_limits[1]) // 2
                    dv_limits.append(y)
                    dv_limits.append(y + (3*ind_size//2))
                    dvLineList.append({"partners": [box["affected_member"],ID], "x_pos": x_pos, "y_pos": dv_limits, "generation": box["generation"]})

            it += 1

    siblingLineList = [] # horizontal lines connecting all siblings in same generation

    # loop over all siblings
    for siblingLine in allSiblingList:
        sibling_idxs = []
        for sibling in siblingLine:
            sibling_idxs.append(get_box_idx(uvLineList1,["id"],[sibling])[0])
        x_positions = []
        y_positions = []
        # list all sibling coordinates
        for sibling_idx in sibling_idxs:
            x_positions.append(uvLineList1[sibling_idx]["x_pos"])
            y_positions.append(uvLineList1[sibling_idx]["y_pos"][0])

        # make sure all y coordinates are equal (error check)
        assert(len(set(y_positions)) == 1)

        # find leftmost and rightmost points for sibling-line
        x_0 = min(x_positions)
        x_1 = max(x_positions)
        # midpoint of sibling line connects with the ancestors
        x_mid = (x_0 + x_1) // 2

        siblingLineList.append({"siblings": siblingLine, "x_pos": [x_0,x_1], "y_pos": y_positions[0]})

        father = uvLineList1[sibling_idxs[0]]["parents"][0]
        mother = uvLineList1[sibling_idxs[0]]["parents"][1]
        generation = uvLineList1[sibling_idxs[0]]["generation"]

        # define upward vertical line from the sibling line to 0.25 basic size up
        y_pos = []
        y_pos.append(y_positions[0] - ind_size//4)
        y_pos.append(y_positions[0])

        uvLineList.append({"parents": [father,mother], "x_pos": x_mid, "y_pos": y_pos, "generation": generation})

    # define lines connecting downward and upward horizontal lines
    connectLineList = []
    for uvline in uvLineList:
        for dvline in dvLineList:
            if lineage == "maternal":
                parent_1 = uvline["parents"][0]
                parent_2 = uvline["parents"][1]
                partner_1 = dvline["partners"][1]
                partner_2 = dvline["partners"][0]
            elif lineage == "paternal":
                parent_1 = uvline["parents"][0]
                parent_2 = uvline["parents"][1]
                partner_1 = dvline["partners"][0]
                partner_2 = dvline["partners"][1]

            if (parent_1 == partner_1) and (parent_2 == partner_2):
                x_pos = []
                y_pos = []

                x_pos.append(uvline["x_pos"])
                x_pos.append(dvline["x_pos"])

                y_pos.append(uvline["y_pos"][0])
                y_pos.append(dvline["y_pos"][1])

                connectLineList.append({"x_pos": x_pos, "y_pos": y_pos})
                break
        continue



    # find repeated individuals on the image, they will be connected with a dashed curve
    repeatMaleList = []
    alreadyListed = []
    for i in range(len(maleList)):
        if maleList[i]["id"] not in alreadyListed:
            for j in range(i+1,len(maleList)):
                if (maleList[i]["id"] == maleList[j]["id"]) and (maleList[i]["id"] != "0") and (maleList[i]["id"] != "unknown"):
                    x_0, y_0 = maleList[i]["center"]
                    x_2, y_2 = maleList[j]["center"]
                    y_0 -= ind_size//2
                    y_2 -= ind_size//2
                    x_1 = (x_0+x_2)//2
                    y_1 = min([y_0,y_2])//4
                    n_points = 5 * ind_size
                    points = [quadratic_bezier(t / n_points, (x_0, y_0), (x_1, y_1), (x_2, y_2)) for t in range(n_points + 1)]
                    repeatMaleList.append({"id" : maleList[i]["id"], "points" : points})
            alreadyListed.append(maleList[i]["id"])

    repeatFemaleList = []
    alreadyListed = []
    for i in range(len(femaleList)):
        if femaleList[i]["id"] not in alreadyListed:
            for j in range(i+1,len(femaleList)):
                if (femaleList[i]["id"] == femaleList[j]["id"]) and (femaleList[i]["id"] != "0") and (femaleList[i]["id"] != "unknown"):
                    x_0, y_0 = femaleList[i]["center"]
                    x_2, y_2 = femaleList[j]["center"]
                    y_0 -= ind_size//2
                    y_2 -= ind_size//2
                    x_1 = (x_0+x_2)//2
                    y_1 = min([y_0,y_2])//4
                    n_points = 500
                    points = [quadratic_bezier(t / n_points, (x_0, y_0), (x_1, y_1), (x_2, y_2)) for t in range(n_points + 1)]
                    repeatFemaleList.append({"id" : femaleList[i]["id"], "points" : points})
            alreadyListed.append(femaleList[i]["id"])

    # draw all the listed elements on the image
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)

    here = path.abspath(path.dirname(__file__))
    # font obtained from https://github.com/kiwi0fruit/open-fonts
    font = ImageFont.truetype(path.join(here,"OpenSans-Regular.ttf"),ind_size//3)

    for circle in femaleList:
        x, y = circle["center"]
        r = circle["radius"]
        color = circle["color"]
        if circle["affected"] == "1":
            if circle["id"] in verifiedList:
                draw.ellipse((x-r, y-r, x+r, y+r), fill=color, outline = "green", width=5)
            elif circle["id"] in unverifiedList:
                draw.ellipse((x-r, y-r, x+r, y+r), fill=color, outline = "orange", width=5)
            else:
                draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
        elif circle["affected"] == "0":
            draw.ellipse((x-r, y-r, x+r, y+r), fill=None, outline = color)


        # write individual's below, move the label by 0.75 the width of the label
        w = draw.textlength(circle["id"])
        draw.text((x-(3*w//4),y+(4*ind_size//5)),circle["id"], (0,0,0),font=font,align="center")

        if (circle["id"] in haplotypedList) and (len(haplotypeMap[circle["id"]]) < 5):
            if circle["id"] in sequencedList :
                draw.text((x-(ind_size//3),(y-(ind_size//5))),haplotypeMap[circle["id"]], (255,255,255),font=font,stroke_width=2,stroke_fill="black")
            else:
                draw.text((x-(ind_size//3),(y-(ind_size//5))),haplotypeMap[circle["id"]], (0,0,0),font=font)


    for rectangle in maleList:
        x, y = rectangle["center"]
        r = rectangle["radius"]
        color = rectangle["color"]
        if rectangle["affected"] == "1":
            if rectangle["id"] in verifiedList:
                draw.rectangle((x-r, y-r, x+r, y+r), fill=color, outline = "green", width=5)
            elif circle["id"] in unverifiedList:
                draw.rectangle((x-r, y-r, x+r, y+r), fill=color, outline = "orange", width=5)
            else:
                draw.rectangle((x-r, y-r, x+r, y+r), fill=color)
        elif rectangle["affected"] == "0":
            draw.rectangle((x-r, y-r, x+r, y+r), fill=None, outline = color, width = 5)

        w = draw.textlength(rectangle["id"])
        draw.text((x-(3*w//4),y+(4*ind_size//5)),rectangle["id"], (0,0,0),font=font,align="center")

        if (rectangle["id"] in haplotypedList) and (len(haplotypeMap[rectangle["id"]]) < 5):
            if rectangle["id"] in sequencedList :
                draw.text((x-(ind_size//3),(y-(ind_size//5))),haplotypeMap[rectangle["id"]], (255,255,255),font=font,stroke_width=2,stroke_fill="black")
            else:
                draw.text((x-(ind_size//3),(y-(ind_size//5))),haplotypeMap[rectangle["id"]], (0,0,0),font=font)

    for hline in hLineList:
        x_0 = hline["endpoints"][0]
        x_1 = hline["endpoints"][1]
        y = hline["y_pos"]
        start_point = (x_0,y)
        end_point = (x_1,y)
        draw.line([start_point, end_point], fill="black", width=5)

    for dvline in dvLineList:
        x = dvline["x_pos"]
        y_0 = dvline["y_pos"][0]
        y_1 = dvline["y_pos"][1]
        start_point = (x,y_0)
        end_point = (x,y_1)
        draw.line([start_point, end_point], fill="black", width=5)

    for uvline in uvLineList:
        x = uvline["x_pos"]
        y_0 = uvline["y_pos"][0]
        y_1 = uvline["y_pos"][1]
        start_point = (x,y_0)
        end_point = (x,y_1)
        draw.line([start_point, end_point], fill="black", width=5)

    for uvline in uvLineList1:
        x = uvline["x_pos"]
        y_0 = uvline["y_pos"][0]
        y_1 = uvline["y_pos"][1]
        start_point = (x,y_0)
        end_point = (x,y_1)
        draw.line([start_point, end_point], fill="black", width=5)

    for siblingLine in siblingLineList:
        start_point = (siblingLine["x_pos"][0],siblingLine["y_pos"])
        end_point = (siblingLine["x_pos"][1],siblingLine["y_pos"])
        draw.line([start_point, end_point], fill="black", width=5)

    for connectline in connectLineList:
        start_point = (connectline["x_pos"][0],connectline["y_pos"][0])
        end_point = (connectline["x_pos"][1],connectline["y_pos"][1])
        draw.line([start_point, end_point], fill="black", width=5)

    dash_length = 5
    gap_length = 1

    for inbreedline in repeatMaleList:
        points = inbreedline["points"]

        for i in range(0, len(points) - dash_length, dash_length + gap_length):
            draw.line((points[i], points[i + dash_length]), fill='black', width=2)

    for inbreedline in repeatFemaleList:

        points = inbreedline["points"]

        for i in range(0, len(points) - dash_length, dash_length + gap_length):
            draw.line((points[i], points[i + dash_length]), fill='black', width=1)

    #plot pedigree
    if mode == "gui":
        image_file, _ = QFileDialog.getSaveFileName(None, "Save image", image_filename, "PNG Files (*.png);;All Files (*)")
    elif mode == "cl":
        image_file = image_filename

    # Save the image
    image.save(image_file)

    return


def line_print(data, ID, startyear, endyear, gen_before, gen_after, lineage, mode, image_filename, image_size):

    if len(data) == 0 and mode == "gui":

        msg = "ERROR: No pedigree is loaded!"
        QMessageBox.critical(None, "ERROR", msg, QMessageBox.StandardButton.Ok)
        return pd.DataFrame()

    if ID == '' and mode == "gui":

        msg = "ERROR: Individual for visualization not defined!"
        QMessageBox.critical(None, "ERROR", msg, QMessageBox.StandardButton.Ok)
        return pd.DataFrame()

    if (endyear != 0) and (startyear > endyear):

        if mode == "gui":
            msg = f"Defined start year {startyear} is later than defined end year {endyear}!"
            QMessageBox.critical(None, "ERROR", msg, QMessageBox.StandardButton.Ok)
        elif mode == "cl":
            sys.stderr.write(f"ERROR: Defined start year {startyear} is later than defined end year {endyear}!\n")
        return pd.DataFrame()

    try:
        if list(data.loc[data['ID'] == ID]['gender'])[0] == '2':
            ancestor_line = 'mother'
            gender = '2'
            gender1 = '2'
            str_gender = 'female'
        elif list(data.loc[data['ID'] == ID]['gender'])[0] == '1':
            if lineage == 'maternal':
                ancestor_line = 'mother'
                gender1 = '2'
                str_gender = 'female'
            elif lineage == 'paternal':
                ancestor_line = 'father'
                gender1 = '1'
                str_gender = 'male'
            gender = '1'

    except IndexError:

        if mode == "gui":
            msg = f"Individual {ID} not found in the pedigree!"
            QMessageBox.critical(None, "ERROR", msg, QMessageBox.StandardButton.Ok)
        elif mode == "cl":
            sys.stderr.write(f"ERROR: Individual {ID} not found in the pedigree!\n")
        return pd.DataFrame()

    allowed_column_names = ['x','ID','father','mother','YOB','gender','oldID','haplotype','available','sequenced','verified']
    cols_to_use = [name for name in data.columns.values if name in allowed_column_names]

    data_types = {}
    for col in cols_to_use:
        if col == 'YOB' or col == 'generation' or col == 'affected':
            data_types[col] = int
        else:
            data_types[col] = str

    if gender == '1' and ancestor_line == 'father':
        data = data.loc[data['gender'] == gender]

    # check if ID is defined in ID column
    if len(list(data[data.ID == ID][ancestor_line])):
        if (list(data[data.ID == ID][ancestor_line])[0] != '0'):
            current = ID
            ancestor = list(data[data.ID == current][ancestor_line])[0]
            while ancestor != '0':
                current = ancestor
                # check if current is defined in ID column, if not add it
                if len(list(data[data.ID == current][ancestor_line])):
                    ancestor = list(data[data.ID == current][ancestor_line])[0]
                else:
                    ancestor = '0'
                    new_row = pd.DataFrame({'ID':[current],'father':['0'],'mother':['0'],'gender':[gender1],'YOB':['0']})
                    data = pd.concat([data,new_row],ignore_index=True)
            founder = current
            message = f"Individual {ID} is not a founder in the {str_gender} line.\nThe founder is {founder}."
            if mode == "gui":
                QMessageBox.information(None, "INFO", message, QMessageBox.StandardButton.Ok)
            elif mode == "cl":
                sys.stdout.write(f"INFO: {message}\n")
        else:
            founder = ID
            message = f"Individual {ID} is the founder in the {str_gender} line."
            if mode == "gui":
                QMessageBox.information(None, "INFO", message, QMessageBox.StandardButton.Ok)
            elif mode == "cl":
                sys.stdout.write(f"INFO: {message}\n")
    else:

        founder = ID
        # add missing founder entry
        new_row = pd.DataFrame({'ID':[ID],'father':['0'],'mother':['0'],'gender':[gender1],'YOB':['0']})
        data = pd.concat([data,new_row],ignore_index=True)
        message = f"Individual {ID} is the founder in the {str_gender} line."
        if mode == "gui":
            QMessageBox.information(None, "INFO", message, QMessageBox.StandardButton.Ok)
        elif mode == "cl":
            sys.stdout.write(f"INFO: {message}\n")

    try:
        graph_tree = pd.DataFrame(build_tree(data,founder,ancestor_line),columns=cols_to_use+['generation','affected'])
    except ValueError:
        message = f"Founder {founder} has no {str_gender} offspring, no output is produced."
        if mode == "gui":
            QMessageBox.critical(None, "ERROR", message, QMessageBox.StandardButton.Ok)
        elif mode == "cl":
            sys.stderr.write(f"ERROR: {message}\n")
        return pd.DataFrame()
 
    graph_tree = graph_tree.astype({'generation':int})


    ID_generation = list(graph_tree[graph_tree.ID == ID]['generation'])[0]
    if gen_before != 0:
        first_gen = int(ID_generation) - int(gen_before)
        graph_tree = graph_tree[graph_tree['generation'] >= first_gen]
    if gen_after != 0:
        last_gen = int(ID_generation) + int(gen_after)
        graph_tree = graph_tree[graph_tree['generation'] <= last_gen]

    try:
        data = pd.DataFrame(graph_tree, columns=cols_to_use+["generation","affected"], dtype=str)
    except ValueError:
        message = f"Founder {founder} has no {str_gender} offspring, no output is produced."
        if mode == "gui":
            QMessageBox.critical(None, "ERROR", message, QMessageBox.StandardButton.Ok)
        elif mode == "cl":
            sys.stderr.write(f"ERROR: {message}\n")
        return pd.DataFrame()

    data = data.astype(data_types)

    if startyear != 0:
        data = data.loc[data['YOB'] >= int(startyear)]
    if endyear != 0:
        data = data.loc[data['YOB'] <= int(endyear)]

    if len(data) <= 1:
        if ancestor_line == 'mother':
            message = f"Founder {founder} has no offspring born from {startyear} to {endyear}."
        elif ancestor_line == 'father':
            message = f"Founder {founder} has no {str_gender} offspring born from {startyear} to {endyear}."
        if mode == "gui":
            QMessageBox.critical(None, "ERROR", message, QMessageBox.StandardButton.Ok)
        elif mode == "cl":
            sys.stderr.write(f"ERROR: {message}\n")
        return pd.DataFrame()

    data = fix_data(data,lineage,ID)

    # if image name is not plot.png, the user wanted some other name
    # otherwise setup another default name by these rules
    if image_filename == "plot.png":

        image_filename = lineage + "_" + ID

        if startyear != 0:
            image_filename += "_from_" + str(startyear)
        if endyear != 0:
            image_filename += "_to_" + str(endyear)
        if gen_before != 0:
            if gen_before > 1:
                image_filename += "_" + str(gen_before) + "_generations_before"
            else:
                image_filename += "_" + str(gen_before) + "_generation_before"
        if gen_after != 0:
            if gen_after > 1:
                image_filename += "_" + str(gen_after) + "_generations_after"
            else:
                image_filename += "_" + str(gen_after) + "_generation_after"
            
        image_filename += ".png"


    visualize_line(data, mode, image_filename, image_size, lineage)

    return data
