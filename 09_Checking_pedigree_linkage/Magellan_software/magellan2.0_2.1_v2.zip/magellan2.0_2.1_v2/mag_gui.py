# This code is a part of Maternal Genealogy Lineage Analyser - MaGelLAn-v2.0demo.
# MaGelLAn is an open source software and it is free for non-commercial use, as long as it is properly referenced.
# Authors are Ino Curik, Dalibor Hrsak and Strahil Ristov

from os import path
import pandas as pd
import numpy as np
import dask.dataframe as dd
from PyQt6.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QHBoxLayout, QMessageBox, QLabel, QFileDialog, QDialog, QTableWidget, QTableWidgetItem, QTabWidget, QRadioButton, QButtonGroup, QTextEdit, QLineEdit
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt
from mag_verif import check_errors, check_haplotype_conflicts, impute_haplotype
from mag_stat import mag_stat
from mag_calc import mag_calc
from mag_sampl import MagSampl
from mag_recode import recode
from mag_viz import line_print
from mag_snp import analyze_SNP, save_fasta, check_mutations, SNPClassifier

#class DisplayPedigreeDF(QWidget):
class DisplayPedigreeDF(QDialog):

    def __init__(self, data, filename, parent=None):
        super().__init__(parent)
        
        self.setWindowTitle(filename)

        self.table_widget = QTableWidget()
        
        self.table_widget.setRowCount(data.shape[0])
        self.table_widget.setColumnCount(data.shape[1])
        
        self.table_widget.setHorizontalHeaderLabels(data.columns)
        
        for i in range(data.shape[0]):
            for j in range(data.shape[1]):
                self.table_widget.setItem(i, j, QTableWidgetItem(str(data.iat[i, j])))

        layout = QVBoxLayout()
        layout.addWidget(self.table_widget)
        self.setLayout(layout)

class MagellanQt(QWidget):

    def __init__(self):

        super().__init__()
        self.setWindowTitle('Magellan-v2.1')
        self.resize(750, 750)
        
        # set class variables to default settings
        self.Lineage = "maternal"
        self.VerifObject = 'haplogroup'
        self.ImputReliability = "high"
        self.FirstRefYearStat = 0
        self.LastRefYearStat = 0
        self.FirstRefYearCalc = 0
        self.LastRefYearCalc = 0
        self.FirstRefYearSampl = 0
        self.LastRefYearSampl = 0
        self.founder = ""
        self.K = 100
        self.SamplingMethod = 'greedy'
        self.start_year = 0
        self.end_year = 0
        self.generations_before = 0
        self.generations_after = 0
        self.ImageSize = 'medium'
        self.gc_score_thresh = 0.0
        self.gt_score_thresh = 0.0
        self.snp_position = 'MT'
        self.sequence_source = 'PED'

        # create labels on the main panel
        label1 = QLabel("Welcome to Maternal Genealogy Lineage Analyser v2.1")
        font = QFont("Arial", 18, QFont.Weight.Bold) 
        label1.setFont(font)
        label1.setStyleSheet("color: green;") 

        label2 = QLabel("Authors: V. Brajkovic, I. Curik, D. Hrsak, S. Ristov")
        font = QFont("Arial", 14, QFont.Weight.Bold) 
        label2.setFont(font)

        label3 = QLabel("MaGelLAn v2.1 is licenced under GNU General Public License v3.0")
        font = QFont("Arial", 12, QFont.Weight.Bold) 
        label3.setFont(font)

        # create buttons to open and show pedigrees, as well as to close the program
        btn_open_pdg = QPushButton("Load CSV")
        btn_display_pdg = QPushButton("Display pedigree file")
        btn_close = QPushButton("Close program")

        btn_open_pdg.clicked.connect(self.open_csv_file)
        btn_display_pdg.clicked.connect(self.display_dataframe)
        btn_close.clicked.connect(self.close)

        # create buttonbar and put the 3 buttons in it 
        Buttonbar_main = QHBoxLayout()
        Buttonbar_main.addWidget(btn_open_pdg)
        Buttonbar_main.addWidget(btn_display_pdg)
        Buttonbar_main.addWidget(btn_close)

        # create buttons to recode pedigree 
        btn_recode_pdg = QPushButton("Run ID recode to numerical")
        btn_save_recoded_pdg = QPushButton("Save recoded pedigree as")

        btn_recode_pdg.clicked.connect(self.run_recode)
        btn_save_recoded_pdg.clicked.connect(self.save_recoded_csv)

        # create buttonbar and put the 2 buttons in it
        Buttonbar_recode = QHBoxLayout()
        Buttonbar_recode.addWidget(btn_recode_pdg)
        Buttonbar_recode.addWidget(btn_save_recoded_pdg)

        # create tab control, each module goes to its own tab
        tabControl = QTabWidget()
        self.VerifTab = QWidget()
        self.StatTab = QWidget()
        self.CalcTab = QWidget()
        self.SamplTab = QWidget()
        self.VizTab = QWidget()
        self.SNPTab = QWidget()

        # each tab is set up in its own function
        self.VerifTabUI()
        self.StatTabUI()
        self.CalcTabUI()
        self.SamplTabUI()
        self.VizTabUI()
        self.SNPTabUI()
        
        # add module tabs to tab control
        tabControl.addTab(self.VerifTab, "mag_verif")
        tabControl.addTab(self.StatTab, "mag_stat")
        tabControl.addTab(self.CalcTab, "mag_calc")
        tabControl.addTab(self.SamplTab, "mag_sampl")
        tabControl.addTab(self.VizTab, "mag_viz")
        tabControl.addTab(self.SNPTab, "mag_snp")

        # main window layout with labels, principal buttons and tab control
        layout = QVBoxLayout()
        layout.addWidget(label1)
        layout.addWidget(label2)
        layout.addWidget(label3)
        layout.addLayout(Buttonbar_main)
        layout.addLayout(Buttonbar_recode)
        layout.addWidget(tabControl)

        self.setLayout(layout)

        return

    # function to create widgets for the verification tab
    def VerifTabUI(self):

        label = QLabel("MaGelLAn verification module")
        font = QFont("Arial", 10, QFont.Weight.Bold) 
        label.setFont(font)

        # create a horizontal bar for radio buttons for lineage selection
        verifbar_lineage = QWidget()
        verifbar_layout_lineage = QHBoxLayout()

        verifbar_layout_lineage.addWidget(QLabel("Lineage for conflict check:"))

        radioBar_lineage = QButtonGroup()
        maternal_button = QRadioButton("Maternal")
        paternal_button = QRadioButton("Paternal")

        maternal_button.setChecked(True)
        maternal_button.toggled.connect(lambda:self.btn_set_state(maternal_button))
        paternal_button.toggled.connect(lambda:self.btn_set_state(paternal_button))

        radioBar_lineage.addButton(maternal_button)
        radioBar_lineage.addButton(paternal_button)
        
        radio_layout_lineage = QHBoxLayout()
        radio_layout_lineage.addWidget(maternal_button)
        radio_layout_lineage.addWidget(paternal_button)

        verifbar_layout_lineage.addLayout(radio_layout_lineage)
        verifbar_lineage.setLayout(verifbar_layout_lineage)

        # create a hirozontal bar for radio buttons for object of verification selection
        verifbar_object = QWidget()
        verifbar_layout_object = QHBoxLayout()

        verifbar_layout_object.addWidget(QLabel("Object of verification:"))

        radioBar_object = QButtonGroup()
        haplo_button = QRadioButton("Haplogroup")
        snp_button = QRadioButton("SNP Sequence")

        haplo_button.setChecked(True)
        haplo_button.toggled.connect(lambda:self.btn_set_state(haplo_button))
        snp_button.toggled.connect(lambda:self.btn_set_state(snp_button))

        radioBar_object.addButton(haplo_button)
        radioBar_object.addButton(snp_button)
        
        # Add radio buttons to the layout
        radio_layout_object = QHBoxLayout()
        radio_layout_object.addWidget(haplo_button)
        radio_layout_object.addWidget(snp_button)

        verifbar_layout_object.addLayout(radio_layout_object)
        verifbar_object.setLayout(verifbar_layout_object)

        # add a bar with Run button as well as a button to inspect results and clear canvas
        verifbar_run = QWidget()
        verifbar_layout_run = QHBoxLayout()

        btn_run_verif = QPushButton("Run mag_verif")
        btn_verif_result = QPushButton("View report")
        btn_verif_del = QPushButton("Clear report")

        btn_run_verif.clicked.connect(self.run_mag_verif)
        btn_verif_result.clicked.connect(self.open_verif_report)
        btn_verif_del.clicked.connect(self.delete_verif_report)

        verifbar_layout_run.addWidget(btn_run_verif)
        verifbar_layout_run.addWidget(btn_verif_result)
        verifbar_layout_run.addWidget(btn_verif_del)
        verifbar_run.setLayout(verifbar_layout_run)

        # create a horizontal bar for haplotype imputation widgets
        verifbar_impute = QWidget()
        verifbar_layout_impute = QHBoxLayout()

        verifbar_layout_impute.addWidget(QLabel("Haplotype imputation:"))

        btn_verif_imp = QPushButton("Impute haplotype")
        btn_verif_imp.clicked.connect(self.run_impute)

        # create radio buttons for reliability selection
        radioBar_reliability = QButtonGroup()
        high_button = QRadioButton("high")
        low_button = QRadioButton("low")

        high_button.setChecked(True)
        high_button.toggled.connect(lambda:self.btn_set_state(high_button))
        low_button.toggled.connect(lambda:self.btn_set_state(low_button))

        radioBar_reliability.addButton(high_button)
        radioBar_reliability.addButton(low_button)

        # add reliability radio buttons to the reliability layout
        radio_layout_reliability = QHBoxLayout()
        radio_layout_reliability.addWidget(QLabel("Reliability:"))
        radio_layout_reliability.addWidget(high_button)
        radio_layout_reliability.addWidget(low_button)

        # button to save the pedigree with imputed haplotype
        btn_save_imp = QPushButton("Save imputed CSV as")
        btn_save_imp.clicked.connect(self.save_imputed_csv)

        # add the buttons to the layout
        verifbar_layout_impute.addWidget(btn_verif_imp)
        verifbar_layout_impute.addLayout(radio_layout_reliability)
        verifbar_layout_impute.addWidget(btn_save_imp)
        verifbar_impute.setLayout(verifbar_layout_impute)

        # add canvas to display summary report
        self.txt_canvas_verif = QTextEdit(self)
        self.txt_canvas_verif.setMinimumSize(200, 100)
        self.txt_canvas_verif.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)

        # main layout for mag_verif tab
        main_layout = QVBoxLayout()
        main_layout.addWidget(label)
        main_layout.addWidget(verifbar_lineage)
        main_layout.addWidget(verifbar_object)
        main_layout.addWidget(verifbar_run)
        main_layout.addWidget(verifbar_impute)
        main_layout.addWidget(self.txt_canvas_verif)
        self.VerifTab.setLayout(main_layout)

        return

    # function to create widgets for the statistics tab
    def StatTabUI(self):

        label = QLabel("MaGelLAn statistics module")
        font = QFont("Arial", 10, QFont.Weight.Bold) 
        label.setFont(font)

        # create a horizontal bar widget for first reference year selection
        statbar_first_ref_year = QWidget()
        statbar_layout_first_ref_year = QHBoxLayout()

        statbar_first_ref_year.setLayout(statbar_layout_first_ref_year)

        entry_first_ref_year = QLineEdit(self)
        entry_first_ref_year.setPlaceholderText("Enter the start reference year.")

        def set_startyear():
            try:
                self.FirstRefYearStat = int(entry_first_ref_year.text())
            except ValueError:
                msg = "ERROR: the value you have entered is not a valid integer!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_first_ref_year = QPushButton("Set", self)
        btn_set_first_ref_year.clicked.connect(set_startyear)


        statbar_layout_first_ref_year.addWidget(QLabel("Start reference year:"))
        statbar_layout_first_ref_year.addWidget(entry_first_ref_year)
        statbar_layout_first_ref_year.addWidget(btn_set_first_ref_year)

        # create a horizontal bar widget for last reference year selection
        statbar_last_ref_year = QWidget()
        statbar_layout_last_ref_year = QHBoxLayout()

        statbar_last_ref_year.setLayout(statbar_layout_last_ref_year)

        entry_last_ref_year = QLineEdit(self)
        entry_last_ref_year.setPlaceholderText("Enter the end reference year.")

        def set_lastyear():
            try:
                self.LastRefYearStat = int(entry_last_ref_year.text())
            except ValueError:
                msg = "ERROR: the value you have entered is not a valid integer!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_last_ref_year = QPushButton("Set", self)
        btn_set_last_ref_year.clicked.connect(set_lastyear)

        statbar_layout_last_ref_year.addWidget(QLabel("End reference year:"))
        statbar_layout_last_ref_year.addWidget(entry_last_ref_year)
        statbar_layout_last_ref_year.addWidget(btn_set_last_ref_year)

        # create a horizontal bar for radio buttons for lineage selection
        statbar_lineage = QWidget()
        statbar_layout_lineage = QHBoxLayout()

        statbar_layout_lineage.addWidget(QLabel("Select lineage:"))

        radioBar_lineage = QButtonGroup()
        maternal_button = QRadioButton("Maternal")
        paternal_button = QRadioButton("Paternal")

        maternal_button.setChecked(True)
        maternal_button.toggled.connect(lambda:self.btn_set_state(maternal_button))
        paternal_button.toggled.connect(lambda:self.btn_set_state(paternal_button))

        radioBar_lineage.addButton(maternal_button)
        radioBar_lineage.addButton(paternal_button)
        
        radio_layout_lineage = QHBoxLayout()
        radio_layout_lineage.addWidget(maternal_button)
        radio_layout_lineage.addWidget(paternal_button)

        statbar_layout_lineage.addLayout(radio_layout_lineage)
        statbar_lineage.setLayout(statbar_layout_lineage)

        # add a bar with Run button as well as a button to inspect results and clear canvas
        statbar_run = QWidget()
        statbar_layout_run = QHBoxLayout()

        btn_run_stat = QPushButton("Run mag_stat")
        btn_stat_result = QPushButton("View report")
        btn_stat_del = QPushButton("Clear report")

        btn_run_stat.clicked.connect(self.run_mag_stat)
        btn_stat_result.clicked.connect(self.open_stat_report)
        btn_stat_del.clicked.connect(self.delete_stat_report)

        statbar_layout_run.addWidget(btn_run_stat)
        statbar_layout_run.addWidget(btn_stat_result)
        statbar_layout_run.addWidget(btn_stat_del)
        statbar_run.setLayout(statbar_layout_run)

        # add canvas to display summary report
        self.txt_canvas_stat = QTextEdit(self)
        self.txt_canvas_stat.setMinimumSize(200, 100)
        self.txt_canvas_stat.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)

        # main layout for mag_stat tab
        main_layout = QVBoxLayout()
        main_layout.addWidget(label)
        main_layout.addWidget(statbar_first_ref_year)
        main_layout.addWidget(statbar_last_ref_year)
        main_layout.addWidget(statbar_lineage)
        main_layout.addWidget(statbar_run)
        main_layout.addWidget(self.txt_canvas_stat)
        self.StatTab.setLayout(main_layout)

        return

    # function to create widgets for the calculation tab
    def CalcTabUI(self):

        label = QLabel("MaGelLAn calculation module")
        font = QFont("Arial", 10, QFont.Weight.Bold) 
        label.setFont(font)

        # create a horizontal bar widget for first reference year selection
        calcbar_first_ref_year = QWidget()
        calcbar_layout_first_ref_year = QHBoxLayout()

        calcbar_first_ref_year.setLayout(calcbar_layout_first_ref_year)

        entry_first_ref_year = QLineEdit(self)
        entry_first_ref_year.setPlaceholderText("Enter the start reference year.")

        def set_startyear():
            try:
                self.FirstRefYearCalc = int(entry_first_ref_year.text())
            except ValueError:
                msg = "ERROR: the value you have entered is not a valid integer!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_first_ref_year = QPushButton("Set", self)
        btn_set_first_ref_year.clicked.connect(set_startyear)


        calcbar_layout_first_ref_year.addWidget(QLabel("Start reference year:"))
        calcbar_layout_first_ref_year.addWidget(entry_first_ref_year)
        calcbar_layout_first_ref_year.addWidget(btn_set_first_ref_year)

        # create a horizontal bar widget for last reference year selection
        calcbar_last_ref_year = QWidget()
        calcbar_layout_last_ref_year = QHBoxLayout()

        calcbar_last_ref_year.setLayout(calcbar_layout_last_ref_year)

        entry_last_ref_year = QLineEdit(self)
        entry_last_ref_year.setPlaceholderText("Enter the end reference year.")

        def set_lastyear():
            try:
                self.LastRefYearCalc = int(entry_last_ref_year.text())
            except ValueError:
                msg = "ERROR: the value you have entered is not a valid integer!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_last_ref_year = QPushButton("Set", self)
        btn_set_last_ref_year.clicked.connect(set_lastyear)

        calcbar_layout_last_ref_year.addWidget(QLabel("End reference year:"))
        calcbar_layout_last_ref_year.addWidget(entry_last_ref_year)
        calcbar_layout_last_ref_year.addWidget(btn_set_last_ref_year)

        # create a horizontal bar for radio buttons for lineage selection
        calcbar_lineage = QWidget()
        calcbar_layout_lineage = QHBoxLayout()

        calcbar_layout_lineage.addWidget(QLabel("Select lineage:"))

        radioBar_lineage = QButtonGroup()
        maternal_button = QRadioButton("Maternal")
        paternal_button = QRadioButton("Paternal")

        maternal_button.setChecked(True)
        maternal_button.toggled.connect(lambda:self.btn_set_state(maternal_button))
        paternal_button.toggled.connect(lambda:self.btn_set_state(paternal_button))

        radioBar_lineage.addButton(maternal_button)
        radioBar_lineage.addButton(paternal_button)
        
        radio_layout_lineage = QHBoxLayout()
        radio_layout_lineage.addWidget(maternal_button)
        radio_layout_lineage.addWidget(paternal_button)

        calcbar_layout_lineage.addLayout(radio_layout_lineage)
        calcbar_lineage.setLayout(calcbar_layout_lineage)

        # add a bar with Run button as well as a button to inspect results and clear canvas
        calcbar_run = QWidget()
        calcbar_layout_run = QHBoxLayout()

        btn_run_calc = QPushButton("Run mag_calc")
        btn_calc_result = QPushButton("View report")
        btn_calc_del = QPushButton("Clear report")

        btn_run_calc.clicked.connect(self.run_mag_calc)
        btn_calc_result.clicked.connect(self.open_calc_report)
        btn_calc_del.clicked.connect(self.delete_calc_report)

        calcbar_layout_run.addWidget(btn_run_calc)
        calcbar_layout_run.addWidget(btn_calc_result)
        calcbar_layout_run.addWidget(btn_calc_del)
        calcbar_run.setLayout(calcbar_layout_run)

        # add canvas to display summary report
        self.txt_canvas_calc = QTextEdit(self)
        self.txt_canvas_calc.setMinimumSize(200, 100)
        self.txt_canvas_calc.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)

        # main layout for mag_calc tab
        main_layout = QVBoxLayout()
        main_layout.addWidget(label)
        main_layout.addWidget(calcbar_first_ref_year)
        main_layout.addWidget(calcbar_last_ref_year)
        main_layout.addWidget(calcbar_lineage)
        main_layout.addWidget(calcbar_run)
        main_layout.addWidget(self.txt_canvas_calc)
        self.CalcTab.setLayout(main_layout)

        return

    # function to create widgets for the calculation tab
    def SamplTabUI(self):

        label = QLabel("MaGelLAn sampling module")
        font = QFont("Arial", 10, QFont.Weight.Bold) 
        label.setFont(font)

        # create a horizontal bar widget to set number of sampled individuals (K)
        samplbar_K = QWidget()
        samplbar_layout_K = QHBoxLayout()

        samplbar_K.setLayout(samplbar_layout_K)

        self.entry_K = QLineEdit(self)
        self.entry_K.setPlaceholderText(f'{self.K}')

        def set_K():
            try:
                self.K = int(self.entry_K.text())
            except ValueError:
                msg = "ERROR: the value you have entered is not a valid integer!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_K = QPushButton("Set", self)
        btn_set_K.clicked.connect(set_K)

        # add widgets to the how-many-to-sample bar
        samplbar_layout_K.addWidget(QLabel('How many to sequence'))
        samplbar_layout_K.addWidget(self.entry_K)
        samplbar_layout_K.addWidget(btn_set_K)

        # create a horizontal bar widget for first reference year selection
        samplbar_first_ref_year = QWidget()
        samplbar_layout_first_ref_year = QHBoxLayout()

        samplbar_first_ref_year.setLayout(samplbar_layout_first_ref_year)

        entry_first_ref_year = QLineEdit(self)
        entry_first_ref_year.setPlaceholderText("Enter the start reference year.")

        def set_startyear():
            try:
                self.FirstRefYearSampl = int(entry_first_ref_year.text())
            except ValueError:
                msg = "ERROR: the value you have entered is not a valid integer!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_first_ref_year = QPushButton("Set", self)
        btn_set_first_ref_year.clicked.connect(set_startyear)


        samplbar_layout_first_ref_year.addWidget(QLabel("Start reference year:"))
        samplbar_layout_first_ref_year.addWidget(entry_first_ref_year)
        samplbar_layout_first_ref_year.addWidget(btn_set_first_ref_year)

        # create a horizontal bar widget for last reference year selection
        samplbar_last_ref_year = QWidget()
        samplbar_layout_last_ref_year = QHBoxLayout()

        samplbar_last_ref_year.setLayout(samplbar_layout_last_ref_year)

        entry_last_ref_year = QLineEdit(self)
        entry_last_ref_year.setPlaceholderText("Enter the end reference year.")

        def set_lastyear():
            try:
                self.LastRefYearSampl = int(entry_last_ref_year.text())
            except ValueError:
                msg = "ERROR: the value you have entered is not a valid integer!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_last_ref_year = QPushButton("Set", self)
        btn_set_last_ref_year.clicked.connect(set_lastyear)

        samplbar_layout_last_ref_year.addWidget(QLabel("End reference year:"))
        samplbar_layout_last_ref_year.addWidget(entry_last_ref_year)
        samplbar_layout_last_ref_year.addWidget(btn_set_last_ref_year)

        # create a horizontal bar for radio buttons for lineage selection
        samplbar_lineage = QWidget()
        samplbar_layout_lineage = QHBoxLayout()

        samplbar_layout_lineage.addWidget(QLabel("Select lineage:"))

        radioBar_lineage = QButtonGroup()
        maternal_button = QRadioButton("Maternal")
        paternal_button = QRadioButton("Paternal")

        maternal_button.setChecked(True)
        maternal_button.toggled.connect(lambda:self.btn_set_state(maternal_button))
        paternal_button.toggled.connect(lambda:self.btn_set_state(paternal_button))

        radioBar_lineage.addButton(maternal_button)
        radioBar_lineage.addButton(paternal_button)
        
        radio_layout_lineage = QHBoxLayout()
        radio_layout_lineage.addWidget(maternal_button)
        radio_layout_lineage.addWidget(paternal_button)

        samplbar_layout_lineage.addLayout(radio_layout_lineage)
        samplbar_lineage.setLayout(samplbar_layout_lineage)

        # create a horizontal bar for radio buttons for sampling method selection
        samplbar_method = QWidget()
        samplbar_layout_method = QHBoxLayout()

        samplbar_layout_method.addWidget(QLabel("Select sampling method:"))

        radioBar_method = QButtonGroup()
        greedy_button = QRadioButton("greedy")
        optimal_button = QRadioButton("optimal")

        greedy_button.setChecked(True)
        greedy_button.toggled.connect(lambda:self.btn_set_state(greedy_button))
        optimal_button.toggled.connect(lambda:self.btn_set_state(optimal_button))

        radioBar_method.addButton(greedy_button)
        radioBar_method.addButton(optimal_button)
        
        radio_layout_method = QHBoxLayout()
        radio_layout_method.addWidget(greedy_button)
        radio_layout_method.addWidget(optimal_button)

        samplbar_layout_method.addLayout(radio_layout_method)
        samplbar_method.setLayout(samplbar_layout_method)

        # add a bar with Run button as well as a button to inspect results and clear canvas
        samplbar_run = QWidget()
        samplbar_layout_run = QHBoxLayout()

        btn_run_sampl = QPushButton("Run mag_sampl")
        btn_sampl_result = QPushButton("View report")
        btn_sampl_del = QPushButton("Clear report")

        btn_run_sampl.clicked.connect(self.run_mag_sampl)
        btn_sampl_result.clicked.connect(self.open_sampl_report)
        btn_sampl_del.clicked.connect(self.delete_sampl_report)

        samplbar_layout_run.addWidget(btn_run_sampl)
        samplbar_layout_run.addWidget(btn_sampl_result)
        samplbar_layout_run.addWidget(btn_sampl_del)
        samplbar_run.setLayout(samplbar_layout_run)

        # add canvas to display summary report
        self.txt_canvas_sampl = QTextEdit(self)
        self.txt_canvas_sampl.setMinimumSize(200, 100)
        self.txt_canvas_sampl.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)

        # main layout for mag_calc tab
        main_layout = QVBoxLayout()
        main_layout.addWidget(label)
        main_layout.addWidget(samplbar_K)
        main_layout.addWidget(samplbar_first_ref_year)
        main_layout.addWidget(samplbar_last_ref_year)
        main_layout.addWidget(samplbar_lineage)
        main_layout.addWidget(samplbar_method)
        main_layout.addWidget(samplbar_run)
        main_layout.addWidget(self.txt_canvas_sampl)
        self.SamplTab.setLayout(main_layout)

        return

    # function to create widgets for the visualization tab
    def VizTabUI(self):

        label = QLabel("MaGelLAn visualization module")
        font = QFont("Arial", 10, QFont.Weight.Bold) 
        label.setFont(font)

        # create a horizontal bar widget for ID selection
        vizbar_founder = QWidget()
        vizbar_layout_founder = QHBoxLayout()

        vizbar_founder.setLayout(vizbar_layout_founder)

        self.entry_founder = QLineEdit(self)
        self.entry_founder.setPlaceholderText("Unit ID")

        def set_founder():

            if self.entry_founder.text() != '' and self.entry_founder.text() != 'Unit ID':
                self.founder = self.entry_founder.text()

            else:
                msg = "ERROR:  The ID for visualization not defined!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_founder = QPushButton("Set", self)
        btn_set_founder.clicked.connect(set_founder)


        vizbar_layout_founder.addWidget(QLabel("Enter unit ID:"))
        vizbar_layout_founder.addWidget(self.entry_founder)
        vizbar_layout_founder.addWidget(btn_set_founder)

        # create a horizontal bar widget for first reference year selection
        vizbar_first_ref_year = QWidget()
        vizbar_layout_first_ref_year = QHBoxLayout()

        vizbar_first_ref_year.setLayout(vizbar_layout_first_ref_year)

        entry_first_ref_year = QLineEdit(self)
        entry_first_ref_year.setPlaceholderText("Enter the start reference year.")

        def set_startyear():
            try:
                self.start_year = int(entry_first_ref_year.text())
            except ValueError:
                msg = "ERROR: the value you have entered is not a valid integer!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_first_ref_year = QPushButton("Set", self)
        btn_set_first_ref_year.clicked.connect(set_startyear)


        vizbar_layout_first_ref_year.addWidget(QLabel("Start reference year:"))
        vizbar_layout_first_ref_year.addWidget(entry_first_ref_year)
        vizbar_layout_first_ref_year.addWidget(btn_set_first_ref_year)

        # create a horizontal bar widget for last reference year selection
        vizbar_last_ref_year = QWidget()
        vizbar_layout_last_ref_year = QHBoxLayout()

        vizbar_last_ref_year.setLayout(vizbar_layout_last_ref_year)

        entry_last_ref_year = QLineEdit(self)
        entry_last_ref_year.setPlaceholderText("Enter the end reference year.")

        def set_lastyear():
            try:
                self.end_year = int(entry_last_ref_year.text())
            except ValueError:
                msg = "ERROR: the value you have entered is not a valid integer!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_last_ref_year = QPushButton("Set", self)
        btn_set_last_ref_year.clicked.connect(set_lastyear)

        vizbar_layout_last_ref_year.addWidget(QLabel("End reference year:"))
        vizbar_layout_last_ref_year.addWidget(entry_last_ref_year)
        vizbar_layout_last_ref_year.addWidget(btn_set_last_ref_year)

        # create a horizontal bar widget for selection of generations before ID
        vizbar_generations_before = QWidget()
        vizbar_layout_generations_before = QHBoxLayout()

        vizbar_generations_before.setLayout(vizbar_layout_generations_before)

        self.entry_generations_before = QLineEdit(self)
        self.entry_generations_before.setPlaceholderText("Enter generations before")

        def set_generations_before():
            try:
                self.generations_before = int(self.entry_generations_before.text())
            except ValueError:
                msg = "ERROR: the value you have entered is not a valid integer!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_generations_before = QPushButton("Set", self)
        btn_set_generations_before.clicked.connect(set_generations_before)


        vizbar_layout_generations_before.addWidget(QLabel("Generations before:"))
        vizbar_layout_generations_before.addWidget(self.entry_generations_before)
        vizbar_layout_generations_before.addWidget(btn_set_generations_before)

        # create a horizontal bar widget for last reference year selection
        vizbar_generations_after = QWidget()
        vizbar_layout_generations_after = QHBoxLayout()

        vizbar_generations_after.setLayout(vizbar_layout_generations_after)

        self.entry_generations_after = QLineEdit(self)
        self.entry_generations_after.setPlaceholderText("Enter generations after")

        def set_generations_after():
            try:
                self.generations_after = int(self.entry_generations_after.text())
            except ValueError:
                msg = "ERROR: the value you have entered is not a valid integer!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_generations_after = QPushButton("Set", self)
        btn_set_generations_after.clicked.connect(set_generations_after)

        vizbar_layout_generations_after.addWidget(QLabel("End reference year:"))
        vizbar_layout_generations_after.addWidget(self.entry_generations_after)
        vizbar_layout_generations_after.addWidget(btn_set_generations_after)

        # create a horizontal bar for radio buttons for selection of generations after
        vizbar_lineage = QWidget()
        vizbar_layout_lineage = QHBoxLayout()

        vizbar_layout_lineage.addWidget(QLabel("Select lineage:"))

        radioBar_lineage = QButtonGroup()
        maternal_button = QRadioButton("Maternal")
        paternal_button = QRadioButton("Paternal")

        maternal_button.setChecked(True)
        maternal_button.toggled.connect(lambda:self.btn_set_state(maternal_button))
        paternal_button.toggled.connect(lambda:self.btn_set_state(paternal_button))

        radioBar_lineage.addButton(maternal_button)
        radioBar_lineage.addButton(paternal_button)
        
        radio_layout_lineage = QHBoxLayout()
        radio_layout_lineage.addWidget(maternal_button)
        radio_layout_lineage.addWidget(paternal_button)

        vizbar_layout_lineage.addLayout(radio_layout_lineage)
        vizbar_lineage.setLayout(vizbar_layout_lineage)

        # create a horizontal bar for radio buttons for image size selection
        vizbar_imagesize = QWidget()
        vizbar_layout_imagesize = QHBoxLayout()

        vizbar_layout_imagesize.addWidget(QLabel("Select image size:"))

        radioBar_imagesize = QButtonGroup()
        large_button = QRadioButton("large")
        medium_button = QRadioButton("medium")
        small_button = QRadioButton("small")

        medium_button.setChecked(True)
        large_button.toggled.connect(lambda:self.btn_set_state(large_button))
        medium_button.toggled.connect(lambda:self.btn_set_state(medium_button))
        small_button.toggled.connect(lambda:self.btn_set_state(small_button))

        radioBar_imagesize.addButton(large_button)
        radioBar_imagesize.addButton(medium_button)
        radioBar_imagesize.addButton(small_button)
        
        radio_layout_imagesize = QHBoxLayout()
        radio_layout_imagesize.addWidget(large_button)
        radio_layout_imagesize.addWidget(medium_button)
        radio_layout_imagesize.addWidget(small_button)

        vizbar_layout_imagesize.addLayout(radio_layout_imagesize)
        vizbar_imagesize.setLayout(vizbar_layout_imagesize)

        # add a bar with Run button as well as a button to inspect results and clear canvas
        vizbar_run = QWidget()
        vizbar_layout_run = QHBoxLayout()

        btn_run_viz = QPushButton("Run mag_viz")
        btn_viz_result = QPushButton("Save lineage as")

        btn_run_viz.clicked.connect(self.run_mag_viz)
        btn_viz_result.clicked.connect(self.save_lineage_csv)

        vizbar_layout_run.addWidget(btn_run_viz)
        vizbar_layout_run.addWidget(btn_viz_result)
        vizbar_run.setLayout(vizbar_layout_run)

        # main layout for mag_viz tab
        main_layout = QVBoxLayout()
        main_layout.addWidget(label)
        main_layout.addWidget(vizbar_founder)
        main_layout.addWidget(vizbar_first_ref_year)
        main_layout.addWidget(vizbar_last_ref_year)
        main_layout.addWidget(vizbar_generations_before)
        main_layout.addWidget(vizbar_generations_after)
        main_layout.addWidget(vizbar_lineage)
        main_layout.addWidget(vizbar_imagesize)
        main_layout.addWidget(vizbar_run)
        self.VizTab.setLayout(main_layout)

        return

    def SNPTabUI(self):

        label = QLabel("MaGelLAn SNP analysis module")
        font = QFont("Arial", 10, QFont.Weight.Bold) 
        label.setFont(font)

        # create a horizontal bar widget for GC score threshold selection
        snpbar_gcscore = QWidget()
        snpbar_layout_gcscore = QHBoxLayout()

        snpbar_gcscore.setLayout(snpbar_layout_gcscore)

        self.entry_gcscore = QLineEdit(self)
        self.entry_gcscore.setPlaceholderText(f"{self.gc_score_thresh}")

        def set_gcscore():

            try:
                self.gc_score_thresh = float(self.entry_gcscore.text())
                if (self.gc_store_thresh < .0) or (self.gc_store_thresh > 1.):
                    msg = "ERROR: allowed values are in range 0.0 to 1.0"
                    QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
                    self.gc_store_thresh = 0.0

            except ValueError:
                msg = "ERROR: the value you have entered is not a valid floating point number!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_gcscore = QPushButton("Set", self)
        btn_set_gcscore.clicked.connect(set_gcscore)


        snpbar_layout_gcscore.addWidget(QLabel("Set GC Score Threshold:"))
        snpbar_layout_gcscore.addWidget(self.entry_gcscore)
        snpbar_layout_gcscore.addWidget(btn_set_gcscore)

        # create a horizontal bar widget for GT score threshold selection
        snpbar_gtscore = QWidget()
        snpbar_layout_gtscore = QHBoxLayout()

        snpbar_gtscore.setLayout(snpbar_layout_gtscore)

        self.entry_gtscore = QLineEdit(self)
        self.entry_gtscore.setPlaceholderText(f"{self.gt_score_thresh}")

        def set_gtscore():

            try:
                self.gt_store_thresh = float(self.entry_gtscore.text())
                if (self.gt_store_thresh < .0) or (self.gt_store_thresh > 1.):
                    msg = "ERROR: allowed values are in range 0.0 to 1.0"
                    QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
                    self.gt_store_thresh = 0.0

            except ValueError:
                msg = "ERROR: the value you have entered is not a valid floating point number!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        # button to click Set
        btn_set_gtscore = QPushButton("Set", self)
        btn_set_gtscore.clicked.connect(set_gtscore)


        snpbar_layout_gtscore.addWidget(QLabel("Set GT Score Threshold:"))
        snpbar_layout_gtscore.addWidget(self.entry_gtscore)
        snpbar_layout_gtscore.addWidget(btn_set_gtscore)

        # create a horizontal bar with radio buttons for genome part selection (MT, X, Y, autosome)
        snpbar_genpart = QWidget()
        snpbar_layout_genpart = QHBoxLayout()

        snpbar_layout_genpart.addWidget(QLabel("Part of genome for analysis:"))

        radioBar_genpart = QButtonGroup()
        MT_button = QRadioButton("mitochondrial")
        Y_button = QRadioButton("Y chromosome")
        X_button = QRadioButton("X chromosome")
        autosome_button = QRadioButton("autosome")

        MT_button.setChecked(True)
        MT_button.toggled.connect(lambda:self.btn_set_state(MT_button))
        Y_button.toggled.connect(lambda:self.btn_set_state(Y_button))
        X_button.toggled.connect(lambda:self.btn_set_state(X_button))
        autosome_button.toggled.connect(lambda:self.btn_set_state(autosome_button))

        radioBar_genpart.addButton(MT_button)
        radioBar_genpart.addButton(Y_button)
        radioBar_genpart.addButton(X_button)
        radioBar_genpart.addButton(autosome_button)
        
        radio_layout_genpart = QHBoxLayout()
        radio_layout_genpart.addWidget(MT_button)
        radio_layout_genpart.addWidget(Y_button)
        radio_layout_genpart.addWidget(X_button)
        radio_layout_genpart.addWidget(autosome_button)

        snpbar_layout_genpart.addLayout(radio_layout_genpart)
        snpbar_genpart.setLayout(snpbar_layout_genpart)

        # add a bar with button to load the four input files
        snpbar_load = QWidget()
        snpbar_layout_load = QHBoxLayout()

        btn_load_report = QPushButton("Load final report")
        btn_load_map = QPushButton("Load map file")
        btn_load_snp = QPushButton("Load SNP list")
        btn_load_population = QPushButton("Load population list")

        btn_load_report.clicked.connect(self.load_final_report)
        btn_load_map.clicked.connect(self.load_snp_map)
        btn_load_snp.clicked.connect(self.load_snp_list)
        btn_load_population.clicked.connect(self.load_population)

        snpbar_layout_load.addWidget(btn_load_report)
        snpbar_layout_load.addWidget(btn_load_map)
        snpbar_layout_load.addWidget(btn_load_snp)
        snpbar_layout_load.addWidget(btn_load_population)
        snpbar_load.setLayout(snpbar_layout_load)

        # add a bar with button to run the analysis
        snpbar_run = QWidget()
        snpbar_layout_run = QHBoxLayout()

        btn_run_analysis = QPushButton("Run SNP analysis")
        btn_save_fasta = QPushButton("Save FASTA file")
        btn_check_mutations = QPushButton("Check deleterious mutations")

        btn_run_analysis.clicked.connect(self.run_snp)
        btn_save_fasta.clicked.connect(self.write_fasta)
        btn_check_mutations.clicked.connect(self.mutations_check)

        snpbar_layout_run.addWidget(btn_run_analysis)
        snpbar_layout_run.addWidget(btn_save_fasta)
        snpbar_layout_run.addWidget(btn_check_mutations)
        snpbar_run.setLayout(snpbar_layout_run)

        # add a bar with button to run haplotype classification
        snpbar_classify = QWidget()
        snpbar_layout_classify = QHBoxLayout()

        btn_run_classification = QPushButton("Run classification")
        btn_insert_prediction = QPushButton("Insert predictions")
        btn_save_pedigree = QPushButton("Save pedigree")

        btn_run_classification.clicked.connect(self.run_classify)
        btn_insert_prediction.clicked.connect(self.insert_prediction)
        btn_save_pedigree.clicked.connect(self.save_imputed_csv)

        snpbar_layout_classify.addWidget(btn_run_classification)
        snpbar_layout_classify.addWidget(btn_insert_prediction)
        snpbar_layout_classify.addWidget(btn_save_pedigree)
        snpbar_run.setLayout(snpbar_layout_classify)

        # create a horizontal bar for radio buttons for sequence source selection
        snpbar_seqsource = QWidget()
        snpbar_layout_seqsource = QHBoxLayout()

        snpbar_layout_seqsource.addWidget(QLabel("Select SNP sequence source:"))

        radioBar_seqsource = QButtonGroup()
        pedigree_button = QRadioButton("pedigree")
        fasta_button = QRadioButton("FASTA")

        pedigree_button.setChecked(True)
        pedigree_button.toggled.connect(lambda:self.btn_set_state(pedigree_button))
        fasta_button.toggled.connect(lambda:self.btn_set_state(fasta_button))

        radioBar_seqsource.addButton(pedigree_button)
        radioBar_seqsource.addButton(fasta_button)
        
        radio_layout_seqsource = QHBoxLayout()
        radio_layout_seqsource.addWidget(pedigree_button)
        radio_layout_seqsource.addWidget(fasta_button)

        snpbar_layout_seqsource.addLayout(radio_layout_seqsource)
        snpbar_seqsource.setLayout(snpbar_layout_seqsource)

        # add canvas to display mutations check report
        self.txt_canvas_snp = QTextEdit(self)
        self.txt_canvas_snp.setMinimumSize(200, 100)
        self.txt_canvas_snp.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)


        # main layout for mag_snp tab
        main_layout = QVBoxLayout()
        main_layout.addWidget(label)
        main_layout.addWidget(snpbar_gcscore)
        main_layout.addWidget(snpbar_gtscore)
        main_layout.addWidget(snpbar_genpart)
        main_layout.addWidget(snpbar_load)
        main_layout.addWidget(snpbar_run)
        main_layout.addWidget(snpbar_classify)
        main_layout.addWidget(snpbar_seqsource)
        main_layout.addWidget(self.txt_canvas_snp)
        self.SNPTab.setLayout(main_layout)

        return

    def btn_set_state(self,button):
	
        if button.text() == "Maternal":
            if button.isChecked():
                self.Lineage = "maternal"
	      		
        elif button.text() == "Paternal":
            if button.isChecked():
                self.Lineage = "paternal"

        elif button.text() == "Haplogroup":
            if button.isChecked():
                self.VerifObject = "haplogroup"
	      		
        elif button.text() == "SNP Sequence":
            if button.isChecked():
                self.VerifObject = "snpseq"

        elif button.text() == "high":
            if button.isChecked():
                self.ImputReliability = "high"

        elif button.text() == "low":
            if button.isChecked():
                self.ImputReliability = "low"

        elif button.text() == "greedy":
            if button.isChecked():
                self.SamplingMethod = "greedy"

        elif button.text() == "optimal":
            if button.isChecked():
                self.SamplingMethod = "optimal"

        elif button.text() == "large":
            if button.isChecked():
                self.ImageSize = "large"

        elif button.text() == "medium":
            if button.isChecked():
                self.ImageSize = "medium"

        elif button.text() == "small":
            if button.isChecked():
                self.ImageSize = "small"

        elif button.text() == "mitochondrial":
            if button.isChecked():
                self.snp_position = "MT"

        elif button.text() == "Y chromosome":
            if button.isChecked():
                self.snp_position = "Y"

        elif button.text() == "X chromosome":
            if button.isChecked():
                self.snp_position = "X"

        elif button.text() == "autosome":
            if button.isChecked():
                self.snp_position = "AUTO"

        elif button.text() == "pedigree":
            if button.isChecked():
                self.sequence_source = "PED"

        elif button.text() == "FASTA":
            if button.isChecked():
                self.sequence_source = "FASTA"

        return

    def open_csv_file(self):

        try:
            self.filename, _ = QFileDialog.getOpenFileName(self, "Open a CSV File", "", "CSV Files (*.csv);;All Files (*)")
            self.data = pd.read_csv(self.filename,dtype=np.str_).fillna('')

        except FileNotFoundError:
            if self.filename == "":
                return
            msg = f"Error in opening file {self.filename}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except PermissionError:
            msg = f"You are not allowed to read {self.filename}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except pd.errors.EmptyDataError:
            msg = f"File {self.filename} is empty."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except ValueError:
            msg = f"ValueError in reading file {self.filename}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        else:

            if 'x' in self.data.columns.values:
                self.data.set_index('x',inplace=True)
            
            unnamed = list(filter(lambda a: 'Unnamed' in a, self.data.columns.values))
            
            if len(unnamed):
                self.data.drop(columns=unnamed,inplace=True)
            
            self.data.replace({'father':{'':'0'},
                               'mother':{'':'0'},
                               'YOB':{'':'MISSING_YEAR'}},inplace=True)
            if 'available' in self.data.columns.values:
                self.data.replace({'available':{'':'0'}},inplace=True)
            
            if self.make_maps():
                return
            
            self.IDlist, \
            self.FatherMap, \
            self.MotherMap, \
            self.YobMap, \
            self.GenderMap,\
            FatalError = check_errors(self.IDlist, self.FatherMap, self.MotherMap, self.YobMap, self.GenderMap, "gui")
            
            
            if FatalError:
                msg = "ERROR: There are fatal errors in pedigree."
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        return

    def open_verif_report(self):

        try: 
            txtfile = "OutputVerif_Summary.txt"
            with open(txtfile, 'r') as txt:
                content = txt.read()

        except FileNotFoundError:
            msg = f"File {txtfile} not found!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except PermissionError:
            msg = f"You are not allowed to read {txtfile}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
        else:
            self.txt_canvas_verif.setPlainText(content)

        return

    def delete_verif_report(self):
        self.txt_canvas_verif.clear()

    def open_stat_report(self):

        try:
            if self.Lineage == 'maternal':
                txtfile = "OutputStat_DamLineMembership_1.txt"
            elif self.Lineage == 'paternal':
                txtfile = "OutputStat_SireLineMembership_1.txt"
            with open(txtfile, 'r') as txt:
                content = ""
                for line in txt.readlines():
                    if 'founder' in line:
                        content += line

        except FileNotFoundError:
            msg = f"File {txtfile} not found!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except PermissionError:
            msg = f"You are not allowed to read {txtfile}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
        else:
            self.txt_canvas_stat.setPlainText(content)

        return

    def delete_stat_report(self):

        self.txt_canvas_stat.clear()

    def open_calc_report(self):

        try:
            txtfile = "OutputCalc_InputAndResults.txt"

            with open(txtfile, 'r') as txt:
                content = txt.read()

        except FileNotFoundError:
            msg = f"File {txtfile} not found!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except PermissionError:
            msg = f"You are not allowed to read {txtfile}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        else:
            self.txt_canvas_calc.setPlainText(content)

        return

    def delete_calc_report(self):

        self.txt_canvas_calc.clear()

    def open_sampl_report(self):
        try:
            txtfile = "OutputSampl_DetailedInfo.txt"

            with open(txtfile, 'r') as txt:
                content = txt.read()

        except FileNotFoundError:
            msg = f"File {txtfile} not found!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
        except PermissionError:
            msg = f"You are not allowed to read {txtfile}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
        else:
            self.txt_canvas_sampl.setPlainText(content)

        return

    def delete_sampl_report(self):
        
        self.txt_canvas_sampl.clear()

    def load_final_report(self):

        try:
            cols_to_use = ['SNP Name','Sample ID','Allele1 - Forward','Allele2 - Forward','GC Score']
            report_filename, _ = QFileDialog.getOpenFileName(self, "Select the final report", "", "TXT Files (*.txt);;All Files (*)")
            self.final_table = dd.read_table(report_filename, sep='\t', skiprows=9, header=0, usecols=cols_to_use,dtype=str)

        except FileNotFoundError:
            if report_filename == "":
                return
            msg = f"Error in opening {report_filename}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except PermissionError:
            msg = f"You are not allowed to read {report_filename}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except pd.errors.EmptyDataError:
            msg = f"File {report_filename} is empty."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except ValueError:
            msg = f"ValueError in reading {report_filename}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except IsADirectoryError:
            msg = "No file selected."
            QMessageBox.warning(self, "WARNING", msg, QMessageBox.StandardButton.Ok)

        return

    def load_snp_map(self):

        try:
            cols_to_use = ['Name', 'Chromosome', 'Position', 'GenTrain Score']
            snp_map_file, _ = QFileDialog.getOpenFileName(self, "Select the SNP map file", "", "TXT Files (*.txt);;All Files (*)")
            self.snp_map = dd.read_table(snp_map_file, sep='\t', header=0, usecols=cols_to_use,dtype=str)

        except FileNotFoundError:
            if snp_map_file == "":
                return
            msg = f"Error in opening {snp_map_file}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except PermissionError:
            msg = f"You are not allowed to read {snp_map_file}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except pd.errors.EmptyDataError:
            msg = f"File {snp_map_file} is empty."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except ValueError:
            msg = f"ValueError in reading {snp_map_file}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except IsADirectoryError:
            msg = "No file selected."
            QMessageBox.warning(self, "WARNING", msg, QMessageBox.StandardButton.Ok)

        return

    def load_snp_list(self):

        try:
            snp_310_file, _ = QFileDialog.getOpenFileName(self, "Select the SNP list file", "", "TXT Files (*.txt);;All Files (*)")
            self.SNPs_310 = pd.read_csv(snp_310_file,usecols=["SNP_Name"],dtype=str)

        except FileNotFoundError:
            if snp_310_file == "":
                return
            msg = f"Error in opening {snp_310_file}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except PermissionError:
            msg = f"You are not allowed to read {snp_310_file}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except pd.errors.EmptyDataError:
            msg = f"File {snp_310_file} is empty."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except ValueError:
            msg = f"File {snp_310_file} must contain header SNP_Name."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except IsADirectoryError:
            msg = "No file selected."
            QMessageBox.warning(self, "WARNING", msg, QMessageBox.StandardButton.Ok)

        return

    def load_population(self):

        try:
            cols_to_use = ['Sample_ID', 'Population']
            population_file, _ = QFileDialog.getOpenFileName(self, "Select the population file", "", "TXT Files (*.txt);;All Files (*)")
            self.samples_population = pd.read_table(population_file, sep='\t', header=0, usecols=cols_to_use,dtype=str)

        except FileNotFoundError:
            if population_file == "":
                return

            msg = f"Error in opening file {population_file}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except PermissionError:
            msg = f"You are not allowed to read {population_file}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except pd.errors.EmptyDataError:
            msg = f"File {population_file} is empty."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except ValueError:
            msg = f"ValueError in reading {population_file}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except AssertionError:
            msg = f"AssertionError in reading {population_file}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except IsADirectoryError:
            QMessageBox.warning(self, "", "No file selected.", QMessageBox.StandardButton.Ok)
        
        return

    def run_snp(self):

        try:
            self.taurus_subset, self.proba = analyze_SNP(self.final_table,
                                                         self.snp_map, 
                                                         self.SNPs_310,
                                                         self.samples_population,
                                                         self.gc_score_thresh,
                                                         self.gt_score_thresh,
                                                         self.snp_position,
                                                         "gui")
        except AttributeError:
            msg = "You have not loaded all 4 necessary files!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
        return

    def write_fasta(self):

        filepath, _ = QFileDialog.getSaveFileName(self, "Save FASTA", ".fas", "FASTA Files (*.fas);;All Files (*)")

        if not filepath:
            return

        try:
            save_fasta(filepath, self.proba)
        except AttributeError:
            msg = f"You have not generated data to save to {filepath}!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        return

    def read_fasta(self):

        id2seq = {}
        try:
            fasta_name, _ = QFileDialog.getOpenFileName(self, "Select the FASTA file", "", "FASTA Files (*.fasta);;All Files (*)")
            with open(fasta_name, 'r') as fasta_file:
                for line in fasta_file:
                    if line[0] == ">":
                        sample_id = line[1:].strip()
                    else:
                        snp_sequence = line.strip()
                        id2seq[sample_id] = snp_sequence

        except FileNotFoundError:
            if fasta_name == "":
                return id2seq

            msg = f"Error in opening file {fasta_name}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except PermissionError:
            msg = f"You are not allowed to read {fasta_name}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
        
        return id2seq

    def run_classify(self):

        if self.sequence_source == "PED":

            if not len(self.HaplotypeMap):
                msg = "No haplotypes found in the pedigree!."
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
                return

            self.classifier = SNPClassifier("xgb_main.json",self.HaplotypeMap)
            self.classifier("gui")

        elif self.sequence_source == "FASTA":
            id2seq = self.read_fasta()
            if len(id2seq) == 0:
                return

            self.classifier = SNPClassifier("xgb_main.json",id2seq)
            self.classifier("gui")
        
        return

    def insert_prediction(self):

        if len(self.data) == 0:
            msg = "Pedigree for inserting predictions not loaded!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
            return

        try:
            self.data["haplotype"] = self.data["ID"].map(self.classifier.id2pred)
        except AttributeError:
            msg = "ERROR: classification not performed."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        return

    def mutations_check(self):
            
        try:
            check_mutations(self.taurus_subset,"gui")
        except AttributeError:
            msg = f"You have to run SNP analysis first!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
            return

        try:
            txtfile = "MUTATIONS_ALERT.TXT"

            with open(txtfile, 'r') as txt:
                content = txt.read()

        except FileNotFoundError:
            msg = f"File {txtfile} not found!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except PermissionError:
            msg = f"You are not allowed to read {txtfile}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
        else:
            self.txt_canvas_snp.setPlainText(content)

        return


    def make_maps(self):

        try:
            self.IDlist = list(self.data["ID"])
            self.FatherMap = dict(zip(self.data.ID, self.data.father))
            self.MotherMap = dict(zip(self.data.ID, self.data.mother))
            self.YobMap = dict(zip(self.data.ID, self.data.YOB))
            self.GenderMap = dict(zip(self.data.ID, self.data.gender))

        except KeyError:
            msg = "Mandatory column names are ID, father, mother, YOB and gender!\nCorrect your pedigree accordingly!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
            return 1

        except AttributeError:
            msg = "Mandatory column names are ID, father, mother, YOB and gender!\nCorrect your pedigree accordingly!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
            return 1

        else:

            if 'haplotype' in self.data.columns.values:
                haplotyped_individuals = self.data[self.data['haplotype'] != '']
                self.HaplotypeMap = dict(zip(haplotyped_individuals.ID, haplotyped_individuals.haplotype))
                self.HaplotypedList = list(haplotyped_individuals['ID'])
                self.HaplotypeNamesList = list(set(haplotyped_individuals['haplotype']))
            else:
                self.HaplotypeMap = {}
                self.HaplotypedList = []
                self.HaplotypeNamesList = []
            
            if 'available' in self.data.columns.values:
                self.AvailableMap = dict(zip(self.data.ID, self.data.available))
            else:
                self.AvailableMap = {}

        return 0

    def display_dataframe(self):
        
        try:
            self.pedigree_display = DisplayPedigreeDF(self.data, self.filename, self)
            self.pedigree_display.exec()
        except AttributeError:
            msg = "ERROR: No pedigree file is loaded!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
        
        return

    def run_mag_verif(self):

        try:
            if self.Lineage == 'paternal':
                check_haplotype_conflicts(self.IDlist,
                                          self.FatherMap,
                                          self.HaplotypeMap,
                                          self.HaplotypedList,
                                          self.HaplotypeNamesList,
                                          self.VerifObject,
                                          "gui")
            elif self.Lineage == 'maternal':
                check_haplotype_conflicts(self.IDlist,
                                          self.MotherMap,
                                          self.HaplotypeMap,
                                          self.HaplotypedList,
                                          self.HaplotypeNamesList,
                                          self.VerifObject,
                                          "gui")
        except AttributeError:
            msg = "ERROR: No pedigree file is loaded!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
 
        return
 
    def run_impute(self):

        try:
            if not len(self.HaplotypedList):
                msg = "ERROR: No haplotypes present in the pedigree!"
                QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
                return
        except AttributeError:
            msg = "ERROR: No pedigree file is loaded!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        else:

            ImputedHaplotypeMap,\
            VerifiedList = impute_haplotype(self.Lineage,
                                            self.GenderMap,
                                            self.MotherMap,
                                            self.HaplotypeMap,
                                            self.HaplotypedList,
                                            self.ImputReliability,
                                            "gui")
            
            self.data['haplotype'] = self.data['ID'].map(ImputedHaplotypeMap)
            self.data['sequenced'] = self.data['ID'].isin(self.HaplotypedList).astype(int)
            
            if self.ImputReliability == 'low':
                self.data['verified'] = self.data['ID'].isin(VerifiedList).astype(int)

        return

    def run_mag_stat(self):

        try:
            if self.Lineage == 'paternal':
                mag_stat(self.IDlist,
                         self.FatherMap,
                         self.YobMap,
                         self.GenderMap,
                         self.HaplotypeMap,
                         self.HaplotypedList,
                         self.FirstRefYearStat,
                         self.LastRefYearStat,
                         'paternal',
                         'gui')

            elif self.Lineage == 'maternal':
                mag_stat(self.IDlist,
                         self.MotherMap,
                         self.YobMap,
                         self.GenderMap,
                         self.HaplotypeMap,
                         self.HaplotypedList,
                         self.FirstRefYearStat,
                         self.LastRefYearStat,
                         'maternal',
                         'gui')

        except AttributeError:
            msg = "ERROR: No pedigree file is loaded!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
 
        return

    def run_mag_calc(self):

        try:
            mag_calc(self.IDlist,
                     self.FatherMap,
                     self.MotherMap,
                     self.YobMap,
                     self.GenderMap,
                     self.HaplotypeMap,
                     self.HaplotypedList,
                     self.HaplotypeNamesList,
                     self.FirstRefYearCalc,
                     self.LastRefYearCalc,
                     self.Lineage,
                     'gui')

        except AttributeError:
            msg = "ERROR: No pedigree file is loaded!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
        
        return

    def run_mag_sampl(self):

        try:
            if self.Lineage == 'paternal':
                mag_sampler = MagSampl(self.IDlist,
                                       self.FatherMap,
                                       self.YobMap,
                                       self.GenderMap,
                                       self.HaplotypeMap,
                                       self.HaplotypedList,
                                       self.HaplotypeNamesList,
                                       self.AvailableMap,
                                       'paternal')
            elif self.Lineage == 'maternal':
                mag_sampler = MagSampl(self.IDlist,
                                       self.MotherMap,
                                       self.YobMap,
                                       self.GenderMap,
                                       self.HaplotypeMap,
                                       self.HaplotypedList,
                                       self.HaplotypeNamesList,
                                       self.AvailableMap,
                                       'maternal')

        except AttributeError:
            msg = "ERROR: No pedigree file is loaded!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
        else:
            mag_sampler(self.FirstRefYearSampl,self.LastRefYearSampl,self.SamplingMethod,self.K,"gui")

        return
 

    def run_recode(self):

        try:
            self.recoded_data = recode(self.data)

        except AttributeError:
            msg = "ERROR: No pedigree file is loaded!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        except UnicodeDecodeError:
            msg = "ERROR: No pedigree file is loaded!"
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)

        return

    def run_mag_viz(self):

        self.lineage = line_print(self.data,
                                  self.founder,
                                  self.start_year,
                                  self.end_year,
                                  self.generations_before,
                                  self.generations_after,
                                  self.Lineage,
                                  "gui",
                                  "plot.png",
                                  self.ImageSize)

        return

    def save_recoded_csv(self):

        filepath, _ = QFileDialog.getSaveFileName(self, "Save recoded pedigree", ".csv", "CSV Files (*.csv);;All Files (*)")

        if not filepath:
            return

        try:
            self.recoded_data.to_csv(filepath,index=False)
        except AttributeError:
            msg = f"AttributeError in saving {filepath}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
        except NameError:
            msg = "ERROR: no recoded data generated, run recode!"
            QMessageBox.critical(self, "No data error", msg, QMessageBox.StandardButton.Ok)

        return

    def save_imputed_csv(self):

        msg = "Be careful not to overwrite your original pedigree!."
        QMessageBox.warning(self, "WARNING", msg, QMessageBox.StandardButton.Ok)

        filepath, _ = QFileDialog.getSaveFileName(self, "Save imputed pedigree", ".csv", "CSV Files (*.csv);;All Files (*)")

        if not filepath:
            return

        try:
            self.data.to_csv(filepath,index=False)
        except AttributeError:
            msg = f"AttributeError in saving {filepath}."
            QMessageBox.critical(self, "ERROR", msg, QMessageBox.StandardButton.Ok)
        except NameError:
            msg = "ERROR: no data generated, load them and impute them!"
            QMessageBox.critical(self, "No data error", msg, QMessageBox.StandardButton.Ok)

        return

    def save_lineage_csv(self):

        filepath, _ = QFileDialog.getSaveFileName(self, "Save lineage pedigree", f"{self.founder}.csv", "CSV Files (*.csv);;TSV Files (*.tsv);;All Files (*)")

        if not filepath:
            return

        try:
            if path.splitext(filepath)[1] == '.csv':
                self.lineage.to_csv(filepath,index=False)
            elif path.splitext(filepath)[1] == '.tsv':
                self.lineage.to_csv(filepath,index=False,sep="\t")
            else:
                self.lineage.to_string(filepath,index=False)

        except AttributeError:
            msg = "ERROR: no lineage data present, file not created!"
            QMessageBox.critical(self, "No data error", msg, QMessageBox.StandardButton.Ok)

        except NameError:
            msg = "ERROR: no lineage generated, run print_line!"
            QMessageBox.critical(self, "No data error", msg, QMessageBox.StandardButton.Ok)

        return

def runGUI():
 
    app = QApplication([])
    mag_gui = MagellanQt()
    mag_gui.show()
    app.exec()


if __name__ == "__main__":
    runGUI()
